package one.digitalinnovation.cloudparking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudParkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
